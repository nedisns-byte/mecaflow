# Architecture cible

Frontend PWA -> API HTTPS -> PostgreSQL/SQLite
                       -> stockage photos
                       -> service diagnostic local
                       -> module IA diagnostic

Rôles:
- Patron: tous les dossiers, planning, KPI, facturation
- Chef d'atelier: planning, diagnostics, affectations
- Mécanicien: ses véhicules, chronomètre, mesures, photos
- Réception: clients, véhicules, OR, devis

Modules V2:
- authentification
- ordre de réparation
- devis/factures
- pièces/fournisseurs
- historique VIN
- photos
- notifications
- arbre de diagnostic par constructeur
- import codes défaut
- intégration valise via passerelle locale
