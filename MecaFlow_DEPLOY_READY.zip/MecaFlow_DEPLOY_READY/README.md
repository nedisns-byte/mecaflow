# MecaFlow — projet prêt à publier

## Contenu
- frontend/index.html : application web responsive + PWA
- frontend/manifest.webmanifest : installation sur écran d'accueil
- backend/main.py : API FastAPI + SQLite
- backend/requirements.txt : dépendances
- database/ : emplacement recommandé pour la base

## Lancer localement
Backend:
    cd backend
    pip install -r requirements.txt
    uvicorn main:app --reload --host 0.0.0.0 --port 8000

Frontend:
ouvrir frontend/index.html pour la maquette hors-ligne.
Pour une version cloud, servir le dossier frontend avec un serveur HTTPS et connecter ses appels à /api.

## Mise en production
1. Héberger le backend sur un serveur Python (Render, Railway, Fly.io, VPS ou équivalent).
2. Mettre le frontend sur un hébergement statique HTTPS.
3. Remplacer le stockage local du prototype par les endpoints /api.
4. Ajouter authentification, sauvegardes, rôles patron/mécanicien et stockage photos.
5. Pour l'intégration valise: prévoir un service local/desktop qui communique avec l'interface via WebSocket/HTTP; une page web seule ne peut pas parler directement à toutes les interfaces OBD.
