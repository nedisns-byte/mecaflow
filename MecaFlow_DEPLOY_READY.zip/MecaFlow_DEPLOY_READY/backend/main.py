from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import sqlite3
import os

BASE = Path(__file__).resolve().parent.parent
FRONTEND = BASE / "frontend"
DB = BASE / "mecaflow.db"

app = FastAPI(title="MecaFlow", version="1.0")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("""
      CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plate TEXT NOT NULL,
        make TEXT DEFAULT '',
        model TEXT DEFAULT '',
        year TEXT DEFAULT '',
        mileage TEXT DEFAULT '',
        customer TEXT DEFAULT '',
        problem TEXT DEFAULT '',
        priority TEXT DEFAULT '2',
        status TEXT DEFAULT 'À diagnostiquer'
      )
    """)
    con.commit()
    return con

class Vehicle(BaseModel):
    plate: str
    make: str = ""
    model: str = ""
    year: str = ""
    mileage: str = ""
    customer: str = ""
    problem: str = ""
    priority: str = "2"

@app.get("/api/health")
def health():
    return {"ok": True, "app": "MecaFlow"}

@app.get("/api/vehicles")
def vehicles():
    con = db()
    rows = [dict(r) for r in con.execute("SELECT * FROM vehicles ORDER BY id DESC")]
    con.close()
    return rows

@app.post("/api/vehicles")
def create_vehicle(v: Vehicle):
    if not v.plate.strip():
        raise HTTPException(400, "Immatriculation obligatoire")
    con = db()
    cur = con.execute(
        """INSERT INTO vehicles
        (plate,make,model,year,mileage,customer,problem,priority)
        VALUES (?,?,?,?,?,?,?,?)""",
        (v.plate.strip(),v.make,v.model,v.year,v.mileage,v.customer,v.problem,v.priority)
    )
    con.commit()
    row = dict(con.execute("SELECT * FROM vehicles WHERE id=?", (cur.lastrowid,)).fetchone())
    con.close()
    return row

@app.patch("/api/vehicles/{vehicle_id}")
def update_vehicle(vehicle_id: int, status: str):
    con = db()
    cur = con.execute("UPDATE vehicles SET status=? WHERE id=?", (status, vehicle_id))
    con.commit()
    con.close()
    if cur.rowcount == 0:
        raise HTTPException(404, "Véhicule introuvable")
    return {"ok": True}

# Serve the frontend from the same server.
if FRONTEND.exists():
    app.mount("/assets", StaticFiles(directory=str(FRONTEND)), name="assets")

@app.get("/{path:path}")
def frontend(path: str = ""):
    candidate = FRONTEND / path
    if path and candidate.is_file():
        return FileResponse(candidate)
    return FileResponse(FRONTEND / "index.html")
