MECAFLOW — MISE EN LIGNE

1. Crée un dépôt GitHub nommé mecaflow.
2. Mets TOUT le contenu de ce dossier dans le dépôt (backend, frontend, render.yaml).
3. Sur Render, New > Blueprint, choisis le dépôt GitHub mecaflow.
4. Render détecte render.yaml et lance le service.
5. Attends que le service soit "Live".
6. Ouvre l'URL fournie par Render sur l'iPhone.
7. Safari > Partager > Ajouter à l'écran d'accueil.

IMPORTANT
- La version sert le frontend et l'API depuis le même serveur.
- La base SQLite est incluse pour le prototype.
- Pour une vraie utilisation multi-mécaniciens/production, il faudra ensuite passer à PostgreSQL + comptes utilisateurs + sauvegardes.
